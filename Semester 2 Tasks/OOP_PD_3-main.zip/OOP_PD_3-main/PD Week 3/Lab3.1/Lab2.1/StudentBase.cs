﻿namespace Lab2._1
{
    public class StudentBase
    {
    }
}